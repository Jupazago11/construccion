<?php

namespace App\Providers;

use App\Enums\SystemRole;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Gate::before(function ($user, string $ability): bool|null {
            if (! method_exists($user, 'hasRole')) {
                return null;
            }

            return $user->hasRole(SystemRole::SuperAdmin->value) ? true : null;
        });
    }
}
