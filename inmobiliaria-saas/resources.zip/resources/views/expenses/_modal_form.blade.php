<form
    method="POST"
    action="{{ $action }}"
    data-ajax-form
    class="flex h-full flex-col gap-6"
    x-data='expenseForm(@js($payload), {
        project_id: @js($expense->project_id),
        category_id: @js($expense->category_id),
        subcategory_id: @js($expense->subcategory_id),
        auxiliary_id: @js($expense->auxiliary_id),
        provider_id: @js($expense->provider_id),
        subtotal_amount: @js($expense->subtotal_amount ?? 0),
        tax_amount: @js($expense->tax_amount ?? 0),
        discount_amount: @js($expense->discount_amount ?? 0),
    })'
>
    @csrf
    @if ($method !== 'POST')
        @method($method)
    @endif

    <div class="min-h-0 flex-1 overflow-y-auto pr-1">
        <div class="grid gap-6 md:grid-cols-2">
            <div>
                <x-input-label for="project_id" :value="'Proyecto'" />
                <select id="project_id" name="project_id" x-model="selectedProjectId" x-on:change="syncProject()" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900">
                    <option value="">Selecciona un proyecto</option>
                    <template x-for="project in projects" :key="project.id">
                        <option :value="String(project.id)" x-text="project.name"></option>
                    </template>
                </select>
                <p class="mt-2 text-xs text-stone-500" x-show="selectedProject" x-text="selectedProject ? `Empresa: ${selectedProject.company_name ?? 'Sin empresa'} | Estado: ${selectedProject.status}` : ''"></p>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="project_id"></p>
            </div>

            <div>
                <x-input-label for="expense_number" :value="'Número del gasto'" />
                <x-text-input id="expense_number" name="expense_number" type="text" class="mt-1 block w-full" :value="$expense->expense_number" required />
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="expense_number"></p>
            </div>

            <div>
                <x-input-label for="expense_date" :value="'Fecha del gasto'" />
                <x-text-input id="expense_date" name="expense_date" type="date" class="mt-1 block w-full" :value="optional($expense->expense_date)->format('Y-m-d') ?: $expense->expense_date" required />
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="expense_date"></p>
            </div>

            <div>
                <x-input-label for="payment_method" :value="'Método de pago'" />
                <select id="payment_method" name="payment_method" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900">
                    <option value="">Selecciona un método</option>
                    @foreach (['cash' => 'Efectivo', 'bank_transfer' => 'Transferencia bancaria', 'credit_card' => 'Tarjeta de crédito', 'debit_card' => 'Tarjeta débito', 'other' => 'Otro'] as $value => $label)
                        <option value="{{ $value }}" @selected(($expense->payment_method ?: 'cash') === $value)>{{ $label }}</option>
                    @endforeach
                </select>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="payment_method"></p>
            </div>

            <div>
                <x-input-label for="category_id" :value="'Categoría'" />
                <select id="category_id" name="category_id" x-model="selectedCategoryId" x-on:change="syncCategory()" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900">
                    <option value="">Selecciona una categoría</option>
                    <template x-for="category in categories" :key="category.id">
                        <option :value="String(category.id)" x-text="category.name"></option>
                    </template>
                </select>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="category_id"></p>
            </div>

            <div>
                <x-input-label for="subcategory_id" :value="'Subcategoría'" />
                <select id="subcategory_id" name="subcategory_id" x-model="selectedSubcategoryId" x-on:change="syncSubcategory()" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900">
                    <option value="">Selecciona una subcategoría</option>
                    <template x-for="subcategory in subcategories" :key="subcategory.id">
                        <option :value="String(subcategory.id)" x-text="subcategory.name"></option>
                    </template>
                </select>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="subcategory_id"></p>
            </div>

            <div>
                <x-input-label for="auxiliary_id" :value="'Auxiliar (opcional)'" />
                <select id="auxiliary_id" name="auxiliary_id" x-model="selectedAuxiliaryId" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900">
                    <option value="">Sin auxiliar</option>
                    <template x-for="auxiliary in auxiliaries" :key="auxiliary.id">
                        <option :value="String(auxiliary.id)" x-text="auxiliary.name"></option>
                    </template>
                </select>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="auxiliary_id"></p>
            </div>

            <div>
                <x-input-label for="provider_id" :value="'Proveedor (opcional)'" />
                <select id="provider_id" name="provider_id" x-model="selectedProviderId" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900">
                    <option value="">Sin proveedor</option>
                    <template x-for="provider in availableProviders" :key="provider.id">
                        <option :value="String(provider.id)" x-text="provider.name"></option>
                    </template>
                </select>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="provider_id"></p>
            </div>

            <div>
                <x-input-label for="subtotal_amount" :value="'Subtotal'" />
                <x-text-input id="subtotal_amount" name="subtotal_amount" type="number" min="0" step="0.01" x-model="subtotalAmount" class="mt-1 block w-full" :value="$expense->subtotal_amount ?? 0" required />
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="subtotal_amount"></p>
            </div>

            <div>
                <x-input-label for="tax_amount" :value="'Impuesto'" />
                <x-text-input id="tax_amount" name="tax_amount" type="number" min="0" step="0.01" x-model="taxAmount" class="mt-1 block w-full" :value="$expense->tax_amount ?? 0" />
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="tax_amount"></p>
            </div>

            <div>
                <x-input-label for="discount_amount" :value="'Descuento'" />
                <x-text-input id="discount_amount" name="discount_amount" type="number" min="0" step="0.01" x-model="discountAmount" class="mt-1 block w-full" :value="$expense->discount_amount ?? 0" />
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="discount_amount"></p>
            </div>

            <div>
                <x-input-label for="status" :value="'Estado'" />
                <select id="status" name="status" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900">
                    @foreach (['active' => 'Activo', 'inactive' => 'Inactivo'] as $value => $label)
                        <option value="{{ $value }}" @selected(($expense->status ?: 'active') === $value)>{{ $label }}</option>
                    @endforeach
                </select>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="status"></p>
            </div>

            <div class="md:col-span-2">
                <div class="rounded-3xl border border-stone-200 bg-stone-50 px-4 py-4">
                    <p class="text-xs uppercase tracking-wide text-stone-400">Total calculado</p>
                    <p class="mt-2 text-2xl font-semibold text-stone-900" x-text="totalAmount"></p>
                </div>
            </div>

            <div class="md:col-span-2">
                <x-input-label for="description" :value="'Descripción'" />
                <textarea id="description" name="description" rows="5" class="mt-1 block w-full rounded-2xl border-stone-300 shadow-sm focus:border-stone-900 focus:ring-stone-900" required>{{ $expense->description }}</textarea>
                <p class="mt-2 hidden text-sm text-rose-600" data-error-for="description"></p>
            </div>
        </div>
    </div>

    <div class="sticky bottom-0 flex items-center justify-end gap-3 border-t border-stone-200 bg-white pt-5">
        <button type="button" data-action="close-modal" class="rounded-2xl border border-stone-300 px-4 py-2 text-sm font-medium text-stone-700 transition hover:bg-stone-50">
            Cancelar
        </button>
        <button type="submit" class="rounded-2xl bg-stone-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-stone-700">
            {{ $expense->exists ? 'Actualizar gasto' : 'Crear gasto' }}
        </button>
    </div>
</form>
